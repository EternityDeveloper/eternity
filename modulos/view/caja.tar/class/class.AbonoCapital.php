<?php

/*MANEJA LO CONSERNIENTE A ABONO A CAPITAL*/
class AbonoCapital{
	private $db_link;
	private $_data;
	
	public function __construct($db_link){
		$this->db_link=$db_link;
	}
 	
}

?>