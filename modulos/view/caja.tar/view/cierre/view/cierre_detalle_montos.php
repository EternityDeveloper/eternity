<?php 
if (!isset($protect)){
	exit;	
}

?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-bordered table-striped" >
  <tr>
    <td>DESCRIPCION</td>
    <td>MONTO</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
