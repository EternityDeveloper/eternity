<table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" style="margin-left:20px;">
  <tr>
    <td rowspan="3" valign="top">dafsd
      <ul id="group_item" class="connectedSortable sort_v">
      </ul></td>
    <td height="50" valign="top">
<ul id="conainer_top_item" class="connectedSortable sort"></ul></td>
  </tr>
  <tr>
    <td valign="top">
 <ul id="view_item" class="connectedSortable sort"></ul>   
    </td>
  </tr>
  <tr>
    <td valign="top" id="table_view">&nbsp;</td>
  </tr>
</table>